package com.packt.j11intro.intcalc;

public class InterestCalculator {
    public InterestCalculator() {
        // Constructor
    }

    public int calcInterest(int owedInCents, int ratePerc) {
        return 0;
    }
}
